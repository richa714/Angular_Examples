import { BrowserModule } from '@angular/platform-browser';
import {NgModule}  from '@angular/core';
import {TrialComponent} from './component';

@NgModule({
    declarations:[TrialComponent],
    imports:[BrowserModule],
    providers:[],
    bootstrap:[TrialComponent]    
    })
export class TrialModule{}