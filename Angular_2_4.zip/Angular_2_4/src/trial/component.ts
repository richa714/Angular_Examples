import {Component} from '@angular/core';

@Component ({
    selector:'abc-root',
    templateUrl:'./component.html',
    styleUrls:[]
    })
export class TrialComponent{
        title='Hello Trial';
    }