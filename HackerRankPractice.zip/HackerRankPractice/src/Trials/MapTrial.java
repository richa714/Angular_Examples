package Trials;

public class MapTrial<K,V> {

}
