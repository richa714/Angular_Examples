package Trials;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CollectionsBasic extends Modification{
	public static void main(String args[])
	{
		CollectionsBasic c=new CollectionsBasic();
	Collection<String> a=new ArrayList<String>();
	a.add("aaaa");
	a.add("zzz");
	a.add("xxx");
	System.out.println("before swapping"+a.size());
	for(String a1:a)
	{
		System.out.println(a1);
	}
		Collections.swap((java.util.List<?>) a, 1, 2);
	
		System.out.println("after swapping");
		for(String a1:a)
		{
			System.out.println(a1);
		}
		
		
	}
	
	
	

}
