package Trials;

import java.util.Scanner;

public class ConsecutiveBinary {
	
	public static void main(String args[])
	{
	int n,rem;
	int max=0;
	int consec=0,i=0;
	//int[] a=new int[10];
	
		Scanner scan= new Scanner(System.in);
	System.out.println("enter decimal number");
	n=scan.nextInt();
	while(n>0)
	{
		rem=n%2;
		n=n/2;
		//a[i]=rem;
		//i++;
		if(rem==1)
		{
	
			max++;
			//System.out.println("inside if max-- "+max);
			if(consec<max)
			consec=max;
			
		}
		else
		{//System.out.println("inside else max-- "+max);
			//consec=max;
			max=0;
		
		}
		
		 
		
		
	}
	
	System.out.println("max-- "+max);
	System.out.println("consec-- "+consec);
	
	}

	
	

}
