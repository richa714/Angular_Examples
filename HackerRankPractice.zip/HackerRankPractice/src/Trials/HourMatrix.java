package Trials;

import java.util.ArrayList;
import java.util.Random;

public class HourMatrix {

	public static void main(String args[])
	{
		int[][] a=new int[5][5];
		int n;
		int max=10;
		int min=5;
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				Random rand = new Random();
			a[i][j]=rand.nextInt(max-min)+min;	
			}
		}
		
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				System.out.println(a[i][j]);
			}
		}
	}
	
}
