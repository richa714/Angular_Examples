package Trials;

public class CollectionsPractice {
	
	public static void main(String... args){
		Employee[] e=new Employee[2];
		e[0]=new Employee();
		e[1]=new Employee();
		e[0].setId(101);
		e[0].setName("abc");
		e[1].setId(202);
		e[1].setName("xyz");
		String s[]=new String[2];
				
				
		for(int i=0;i<e.length;i++)
		{
			s[e[i].getId()]=new String();
			s[e[i].getId()]=e[i].getName();
			
		}
		
		for(String s1:s ){
			System.out.println(s1);
		}
		
		
		
		
	}

}

class Employee
{
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
