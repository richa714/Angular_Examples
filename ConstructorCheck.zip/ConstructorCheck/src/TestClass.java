
public class TestClass {
	private static  String name;
		TestClass(S){
		this.name=name;	
		}
	
private	TestClass(String name){
	this.name=name;	
	}
public static void main(String []args){
	TestClass java8Runner = () ‐>{
		 System.out.println("I am running");
		 };
System.out.println(t.name);	
}
}
