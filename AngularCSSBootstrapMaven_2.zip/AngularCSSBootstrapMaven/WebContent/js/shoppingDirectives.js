app
		.directive(
				'shoppingPanel',
				function() {
					// alert('in directive');
					return {

						restrict : 'EA',
						replace : true,
						scope : {
							imageData : '=imageData',
							
						},
						/*
						 * link:function(scope,element,attrs) {
						 * scope.$watch('imageData',function() {
						 * console.log('shopping list in link function');
						 * console.log(scope.imageData); }) },
						 */
					
						template : '<table border=1>'
								+ '<tr ng-repeat= "i in imageData"><td><a ng-href="#itemDetails/{{i.imageName}}/{{i.imageId}}"><img src="{{i.imagePath}}"></a></td>'
								+ '</tr>' + '</table>'

					};
				});
app
		.directive(
				'itemDetails',
				function() {
					alert('in item alert directive');
					return {
						restrict : 'EA',
						replace : true,
						scope : {
							itemData : "=itemData",
								rating:"=rating"
						},
						link : function(scope) {
							console.log(scope.itemData);
						},
						template : '<div class="row">'
								+ '<div col-md-3>'
								+ '<img src={{itemData.imagePath}} height="300px" width="100px">'								
								+ '<div col-md-3>'
								+ 'Name: <span ng-bind=itemData.itemName></span><br>'
								+ 'Description: <span ng-bind=itemData.itemDescription></span><br>'
								+ 'Price: <span ng-bind=itemData.itemPrice></span><br>'
								+ 'Rating: <span ng-bind=itemData.itemRating></span><div ng-repeat="i in rating" style="float:left"><span id="star">&#x02605</span></div>'
								+ '</div></div>' + '</div>'
					};

				}

		);
