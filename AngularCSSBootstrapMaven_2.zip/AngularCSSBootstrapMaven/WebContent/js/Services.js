app.factory('AnimalDataService', function($resource) {
	return $resource('api/getAnimalData', {}, {
		getData : {
			method : 'GET',
			params : {},
			isArray : false
		}

	});
});

app.factory('ShoppingFactory', function($resource) {
	//alert('inside service');
	//alert($routeParams.tabName);

	return $resource('api/getShoppingData', {}, {
		getData : {
			method : 'GET',
			params : {
				tabName : '@shoppingCategory'
			},
			isArray : false
		}

	});
});

app.factory('ItemFactory', function($resource) {
	return $resource('api/getItemDetails', {}, {
		getDetails : {
			method : 'GET',
			params : {
				itemId : '@itemId'				
			},
			isArray : false

		}
	});
});

/*app.service('ShoppingService',function()
 {
 this.bind=function(scope)
 {
 var shoppingCategory=scope.$watch($routeParams.tabName,function()

 {

 console.log($routeParams.tabName);
 });

 this.shoppingCategory=function()
 {
 console.log('watching');
 $watch($routeParams.tabName,function()

 {

 console.log($routeParams.tabName);
 }		

 )

 }	
 }		
 )
 */

app.factory('MenuService', function($resource) {
	return $resource('api/getMenuData/:param1', {}, {
		getData : {
			method : 'POST',
			params : {},
			isArray : false
		}

	});
});

/*app.service('PromiseDemo', function() {

 for ( var i = 0; i < 10000; i++) {
 this.sum = sum + i;
 }
 });*/

app.service('PromiseDemo', function($http, $q) {
	//alert('entering inside service');
	this.getEmployeeList = function() {
		//without promise
		/*$http.get("files/demo.txt")
		.then(function(result){
			console.log('result inside service');
			console.log(result);
		return result; })*/

		var defer = $q.defer();
		$http.get("files/demo.txt").then(function(result) {
			defer.resolve(result);
		});
		return defer.promise;

	}
});
