app.controller('shoppingCtrl', function($scope, $rootScope, $routeParams,$cookieStore,$location,
		ShoppingFactory) {

	if($cookieStore.get("user")==null)
		{
		alert("redirecting");
	
		$location.path("/login");
		}
	else
		{
	console.log("route Params");
	/*
	 * $scope.$watch($routeParams.tabName,function(){ console.log('watching');
	 * console.log($routeParams.tabName); });
	 */
	$scope.shoppingCategory = $routeParams.tabName;
	console.log($scope.shoppingCategory);
	$scope.imageData = {};
	ShoppingFactory.getData({
		shoppingCategory : $scope.shoppingCategory
	}, function(data) {

		//alert('inside service');
		console.log(data);

		$scope.imageData = data.shoppingList;

		console.log('before manipulation');
		console.log($scope.imageData);
		angular.forEach($scope.imageData, function(value, key) {
			console.log(key + " : " + value);
			$scope.imageData[key].imagePath = "images\\"
				+ $scope.imageData[key].imagePath;

		});

		console.log('image data in controller');
		console.log($scope.imageData);
	});
		}
});