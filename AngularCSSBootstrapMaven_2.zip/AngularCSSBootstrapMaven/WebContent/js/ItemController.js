app.controller('itemCtrl', function($scope,$routeParams,ItemFactory) {

	//alert($routeParams.itemId);
	//alert($routeParams.itemName);
	$scope.itemData={};
	ItemFactory.getDetails({
				itemId:$routeParams.itemId				
			},
			function(data) {
				
		console.log(data);
		$scope.itemData={"itemId":data.itemId,"itemName":data.itemName,"itemPrice":data.itemPrice,
				"itemRating":data.itemRating,"itemDescription":data.itemDescription,"imagePath":"images\\"+data.imagePath};
		
		console.log($scope.itemData);
		$scope.rating=[];
		for (var i=1;i<=$scope.itemData.itemRating;i++)
			{
			$scope.rating.push(i);
			}
		console.log($scope.rating);
	});

});
