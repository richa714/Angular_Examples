//var app=angular.module("practiceApp",[]);
//angular.module("practiceApp",[])
app.controller('practiceCtrl', function($scope, $q, $cookieStore, $routeParams,
		$http, $timeout, AnimalDataService, PromiseDemo,ShoppingFactory) {
	// alert("practice controller");
	console.log('inside controller');
	console.log($routeParams.country);
	$cookieStore.put('Eno', '827468');
	/*
	 * $scope.animal={ "animalList":[{ "imageId":undefined,
	 * "imageName":undefined, "imageDescription":undefined,
	 * "imagePath":undefined
	 * 
	 * }]};
	 */
	console.log("******");
	console.log($routeParams.country);
	console.log($cookieStore.get('Eno'));
	$scope.animalobj = {};
	$scope.animalobjCopy = {};
	$scope.animalobjExtend = {};
	$scope.animalList = [];
	// alert("inside controller");
	console.log("before calling service");
	$scope.loader = true;
	console.log($scope.loader);
	// explicitly creating promises to make it synchronous
	// var d=$q.defer();
	AnimalDataService.getData(function(data) {

		$scope.animalobj = data;
		angular.forEach($scope.animalobj.animalList, function(value, key) {
			console.log(key + " : " + value);
			$scope.animalobj.animalList[key].imagePath = "images\\"
					+ $scope.animalobj.animalList[key].imagePath;
			console.log($scope.animalobj.animalList[key].imagePath);
		});
		$scope.loader = false;
		// d.resolve(data);
		console.log($scope.loader);

	}, function(error) {
		// d.reject(error);
		console.log('some error occured');
	});

	/*
	 * $(".progress-bar").animate({ width: "70%" }, 2500 );
	 */

	// alert("checking promise");
	// without promise... it is asynchronous so if $scope is printed before data
	// is actually retreived in service.
	/*
	 * $scope.employeeDetails=PromiseDemo.getEmployeeList(); console.log('data
	 * after promise'); console.log($scope.employeeDetails);
	 */

	// with promise... makes it synchronous and will wait for data to come and
	// then only it moves to next scope.
	var emp = PromiseDemo.getEmployeeList();
	emp.then(function(result) {
		$scope.employeeDetails = result.data;

		// console.log($scope.employeeDetails);
	});
	console.log('***Promise***');
	console.log($scope.employeeDetails);
	
	
	
	
	

	$scope.login = function() {
		$cookieStore.put("user", $scope.user.username);
		$http.post("api/login").success(function() {

			$timeout(function() {
				$cookieStore.remove("user");
			}, 5000);

		}).error(function() {

			console.log("some error occurred");
		});

	};
	
	$scope.promiseCheck=function()
	{/*
		alert("in promise check function");
		var d=$q.defer();
		$http.get('api/getAnimalData')
		.success(function(data)
				{
			console.log("success animal data 1");
			console.log(data);	
			d.resolve(data);
				})
				.error(function()
				{
				console.log("error animal data 1");
				d.reject();
				});
		
		$http.get('api/getShoppingData',
				{
			params:{shoppingCategory:'Electronics'}
		})
		.success(function(data)
				{
			console.log("success shopping data 2");
			console.log(data);	
			d.resolve(data);
				})
				.error(function()
				{
				console.log("error shopping data 2");	
				d.reject();
				});
		d.resolve();
*/
		AnimalDataService.getData(function(data) {

			$scope.animalobj = data;
			angular.forEach($scope.animalobj.animalList, function(value, key) {
				console.log(key + " : " + value);
				$scope.animalobj.animalList[key].imagePath = "images\\"
						+ $scope.animalobj.animalList[key].imagePath;
				console.log($scope.animalobj.animalList[key].imagePath);
			});
			$scope.loader = false;
			// d.resolve(data);
			console.log("success animal data 1");
			console.log(data);	

		}, function(error) {
			// d.reject(error);
			console.log('some error occured');
		});
		
		ShoppingFactory.getData({
			shoppingCategory : 'Electronics'
		}, function(data) {

			//alert('inside service');
			console.log(data);

			$scope.imageData = data.shoppingList;

			console.log('before manipulation');
			console.log($scope.imageData);
			angular.forEach($scope.imageData, function(value, key) {
				console.log(key + " : " + value);
				$scope.imageData[key].imagePath = "images\\"
					+ $scope.imageData[key].imagePath;

			});

			console.log("success shopping data 2");
			console.log(data);	
		});
	
	};

});
