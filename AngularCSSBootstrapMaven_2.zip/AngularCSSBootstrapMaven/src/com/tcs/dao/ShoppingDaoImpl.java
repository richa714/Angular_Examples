package com.tcs.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.tcs.bean.Item;
import com.tcs.bean.Shopping;

@Repository
public class ShoppingDaoImpl implements IShoppingDaoInterface {

	public List<Shopping> getData(SessionFactory sessionFac, String tabName) {

		System.out.println("in DAO");
		Session session = sessionFac.getCurrentSession();
		Query query = session.createQuery("From Shopping where categoryName=?")
				.setParameter(0, tabName);
		List<Shopping> alist = new ArrayList<Shopping>();
		alist = query.list();
		
		for(int i=0;i<10;i++)
		{
			System.out.println("Hello  "+i);
			System.out.println("eeeee"+i+1);
		}
		
		System.out.println("array list size-- " + alist.size());
		for (Shopping s : alist) {

			System.out.println(s.getImagePath());
		}
		// System.out.println("image id--"+alist.get(0).getImageId());
		return alist;

	}

	public Item getItemDetails(SessionFactory sessionFac, Integer itemId) {
		System.out.println("in DAO");
		Session session = sessionFac.getCurrentSession();
		Query query = session
				.createSQLQuery(
						"Select i.id,i.name,i.price,i.rating,i.description,s.image_path as \"imagePath\" From shopping_categories s,item_details i where i.id=s.image_id and i.id=?")
						.addEntity(Item.class).setParameter(0, itemId);
		Item itemDetails = new Item();
		itemDetails = (Item) query.uniqueResult();
		return itemDetails;
	}
}
