package com.tcs.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.tcs.bean.Animal;
import com.tcs.response.AnimalResponse;




@Repository
public class AnimalDaoImpl implements IAnimalDaoInterface {

	private static final Logger LOGGER=Logger.getLogger(AnimalDaoImpl.class.getName());
	

public List<Animal> getData(SessionFactory sessionFac) {
	Set<Integer> s=new HashSet<Integer>();
		LOGGER.log(Level.INFO,"inside DAO");
		//Animal a=null;
		//System.out.println(a.getImageId());
	Session session=sessionFac.getCurrentSession();
	Query query=session.createQuery("FROM Animal");
	List<Animal> alist = new ArrayList<Animal>();
	alist=query.list();
	LOGGER.log(Level.INFO,"before returning from DAO");
	/*for(int i=0;i<100000;i++)
	{
		System.out.println("Hello  "+i);
		System.out.println("eeeee"+i+1);
	}*/
		return alist;
		
	}


	public void callByReference(List<String> alist) {
		System.out.println("in dao before manipulation"+alist.get(0));
		alist.add(1,"Arora");
		
	}

}
