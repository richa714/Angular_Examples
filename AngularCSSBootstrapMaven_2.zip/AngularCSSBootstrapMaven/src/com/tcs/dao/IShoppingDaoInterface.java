package com.tcs.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.tcs.bean.Item;
import com.tcs.bean.Shopping;

public interface IShoppingDaoInterface {
	public List<Shopping> getData(SessionFactory sessionFac,String tabName);
public Item getItemDetails(SessionFactory sessionFac,Integer itemId);
}
