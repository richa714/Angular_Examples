package com.tcs.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.tcs.bean.Animal;
import com.tcs.dao.IAnimalDaoInterface;
import com.tcs.response.AnimalResponse;


public class AnimalServiceImpl implements IAnimalServiceInterface,Cloneable {
	
	@Autowired
	IAnimalDaoInterface adao;
	
	@Autowired 
	SessionFactory sessionFac;
	private int id;

	AnimalServiceImpl(){
		System.out.println("Animal Service implementation empty constructor got called");
		};
		
	AnimalServiceImpl(int id){
		System.out.println("Animal Service implementation parameterized constructor got called "+id);
	this.id=id;
	};
	private static final Logger LOGGER=Logger.getLogger(AnimalServiceImpl.class.getName());
	@Transactional
	public List<Animal> getData() {
		
		LOGGER.log(Level.INFO,"inside service");
		/*Animal an=new Animal();
		an.clone();*/
		return adao.getData(sessionFac);
	}
	public void callByReference() throws CloneNotSupportedException {
		Animal an=new Animal();
		an.setImageName("Varsha");
		Animal an1=an.clone();
		an1.setImageName("Gujrati");
		System.out.println("an---- "+an.getImageName() +"an1-----"+an1.getImageName());
		
		ArrayList<Animal> alist=new ArrayList<Animal>();
		alist.add(an);
		alist.add(an1);
		List<Animal> alist1=(ArrayList<Animal>) alist;
		alist1.remove(0);
		alist1.add(new Animal());
		System.out.println("original Array-- "+alist.get(0).getImageName());
		System.out.println("original Array-- "+alist1.get(0).getImageName());
	ArrayList str=	new ArrayList();
	str.add("Richa");

		adao.callByReference((ArrayList)str.clone());
		System.out.println("in service after dao manipulation-- "+str);
	}
	
	

}
