package com.tcs.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.tcs.bean.Item;
import com.tcs.bean.Shopping;

import com.tcs.response.ShoppingResponse;
import com.tcs.service.IShoppingServiceInterface;

@Controller
public class ShoppingController {

	@Autowired
	IShoppingServiceInterface aservice;
	@Autowired 
	HttpSession httpSession;
	
	private static final Logger LOGGER=Logger.getLogger(ShoppingController.class.getName());
	@RequestMapping(value="/getShoppingData",method=RequestMethod.GET,produces="application/json")
	@ResponseBody public ShoppingResponse getData(@RequestParam String shoppingCategory,HttpSession httpSession)
	{
		LOGGER.log(Level.INFO,"heyyyyyy");
		LOGGER.log(Level.INFO,"Inside shopping Controller");
		System.out.println("tabname-- "+shoppingCategory);	
		List<Shopping> list=new ArrayList<Shopping>();
		list=aservice.getData(shoppingCategory);
		System.out.println("list size in controller"+list.size());
		/*ShoppingResponse response=new ShoppingResponse();
		
		if(list.size()==0||list.isEmpty())
		{
			response.setStatusCode(204);
			response.setStatus("Error");
			response.setMessage("No data found");
			
			
			
		}
		else
		{
			response.setStatusCode(200);
			response.setStatus("Success");
			response.setMessage("Data retreived successfully");
			response.setAnimalList(list);
		}*/
		ShoppingResponse sresponse=new ShoppingResponse();
		sresponse.setShoppingList(list);
		return sresponse;
	}

	@RequestMapping(value="/getItemDetails",method=RequestMethod.GET,produces="application/json")
	@ResponseBody public Item getItemDetails(@RequestParam Integer itemId)
	{
		System.out.println("item id in controller"+itemId);
		Item itemDetails=new Item();
		itemDetails=aservice.getItemDetails(itemId);		
		return itemDetails;
	}
}
