package com.tcs.response;

import java.util.List;

import com.tcs.bean.Shopping;

public class ShoppingResponse {

	List<Shopping> shoppingList;

	public List<Shopping> getShoppingList() {
		return shoppingList;
	}

	public void setShoppingList(List<Shopping> shoppingList) {
		this.shoppingList = shoppingList;
	}
	
}
