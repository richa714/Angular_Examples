package com.tcs.aop;

import java.lang.reflect.Method;

import javax.servlet.http.HttpSession;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;



@Aspect
public class AspectExample {

	//@Pointcut("execution(*ShoppingController.*(..))")
	//! className not working... it is still entering LoginController
	@Pointcut("@annotation(org.springframework.web.bind.annotation.RequestMapping) && !execution(* com.tcs.controller.LoginController.*(..))" )
	public void requestMapping(){}

	@Before("requestMapping()")
	public void advice(JoinPoint jpoint)
	{
		 /*HttpSession session=null;
		 System.out.println("session object in aspect"+session.getAttribute("user"));*/
				 
System.out.println("Executing AOP before @Request Mapping");
MethodSignature signature=(MethodSignature) jpoint.getSignature();
Method method=signature.getMethod();
String mapping=method.getAnnotation(RequestMapping.class).value()[0];
System.out.println(mapping);
//System.out.println("session value-- "+httpSession);
	}

}
