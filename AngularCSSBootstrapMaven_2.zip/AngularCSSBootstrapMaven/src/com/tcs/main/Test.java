package com.tcs.main;

import java.util.HashMap;
import java.util.Map;




public class Test {

	public static void main(String args[])
	{
		System.out.println("Inside Main");
		Map<Employee,String> employeeMap=new HashMap<Employee,String>();
		Employee e1=new Employee();
		e1.setId(1);
		e1.setName("abc");
		Employee e2=new Employee();
		e2.setId(2);
		e2.setName("xyz");
		employeeMap.put(e1,"value 1");
		employeeMap.put(e2,"value 2");
		for(Map.Entry<Employee,String> entry:employeeMap.entrySet())
		{
			System.out.println("entry-- "+entry.getKey().getId()+" name--"+entry.getKey().getName());
			System.out.println("entry value--"+entry.getValue());
		}
	}
	
}


 class Employee
{
	private Integer id;
	private String name;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
