package com.tcs.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity@IdClass(ShoppingKey.class)
@Table(name = "shopping_categories")
public class Shopping{
	
	@Id
	@Column(name = "image_id")
	private Integer imageId;
	
	@Id
	@Column(name = "category_id")
	private Integer categoryId;
	
	
	@Column(name="image_name")
	private String imageName;
	
	@Column(name = "category_name")
	private String categoryName;
	
	@Column(name = "image_path")
	private String imagePath;

	public Integer getImageId() {
		return imageId;
	}

	public void setImageId(Integer imageId) {
		this.imageId = imageId;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

}
