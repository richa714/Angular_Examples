package com.tcs.response;

import java.util.List;

import com.tcs.bean.Animal;
import com.tcs.helper.CommonResponse;

public class AnimalResponse extends CommonResponse{
	private List<Animal> animalList;
	

	public List<Animal> getAnimalList() {
		return animalList;
	}

	public void setAnimalList(List<Animal> animalList) {
		this.animalList = animalList;
	}

	

}
