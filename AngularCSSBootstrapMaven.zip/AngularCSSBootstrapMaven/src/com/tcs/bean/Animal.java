package com.tcs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="animal_images")
public class Animal {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)
@Column(name="image_id")
	private Integer imageId;
@Column(name="image_name")
	private String imageName;
@Column(name="image_path")
	private String imagePath;
@Column(name="image_description")
	private String imageDescription;


	/*public Animal(Integer imageId, String imageName, String imagePath,
		String imageDescription) {
	super();
	this.imageId = imageId;
	this.imageName = imageName;
	this.imagePath = imagePath;
	this.imageDescription = imageDescription;
}*/
	public Integer getImageId() {
		return imageId;
	}
	public void setImageId(Integer imageId) {
		this.imageId = imageId;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getImageDescription() {
		return imageDescription;
	}
	public void setImageDescription(String imageDescription) {
		this.imageDescription = imageDescription;
	}



}
