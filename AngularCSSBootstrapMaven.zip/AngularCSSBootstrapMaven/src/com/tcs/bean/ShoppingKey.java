package com.tcs.bean;

import java.io.Serializable;

import javax.persistence.Column;

public class ShoppingKey implements Serializable{
	@Column(name = "image_id")
	private Integer imageId;
	@Column(name = "category_id")
	private Integer categoryId;

}
