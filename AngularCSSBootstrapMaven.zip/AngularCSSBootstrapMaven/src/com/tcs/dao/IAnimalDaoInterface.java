package com.tcs.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.tcs.bean.Animal;
import com.tcs.response.AnimalResponse;



public interface IAnimalDaoInterface {
	
	public List<Animal> getData(SessionFactory sessionFac);

}
