package com.tcs.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tcs.bean.Animal;
import com.tcs.response.AnimalResponse;
import com.tcs.service.AnimalServiceImpl;
import com.tcs.service.IAnimalServiceInterface;
import com.tcs.service.NewAnimalServiceImpl;

@Controller
public class AnimalController {

	@Qualifier("service1")
	@Autowired	
	IAnimalServiceInterface aservice;

	private static final Logger LOGGER = Logger
			.getLogger(AnimalController.class.getName());

	@RequestMapping(value = "/getAnimalData", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public AnimalResponse getData() {

		LOGGER.log(Level.INFO, "heyyyyyy");
		LOGGER.log(Level.INFO, "Inside Controller");
		List<Animal> list = new ArrayList<Animal>();
		System.out.println("in controller before calling service");
		//aservice=new NewAnimalServiceImpl();
		list = aservice.getData();
Map<Integer,String> m= new HashMap<Integer,String>();
		AnimalResponse response = new AnimalResponse();

		if (list.size() == 0 || list.isEmpty()) {
			response.setStatusCode(204);
			response.setStatus("Error");
			response.setMessage("No data found");

		} else {
			response.setStatusCode(200);
			response.setStatus("Success");
			response.setMessage("Data retreived successfully");
			response.setAnimalList(list);
		}
		return response;
	}

}
