package com.tcs.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.bean.Item;
import com.tcs.bean.Shopping;
import com.tcs.dao.IShoppingDaoInterface;
@Service
public class ShoppingServiceImpl implements IShoppingServiceInterface {

	@Autowired
	IShoppingDaoInterface ishopDao;
	@Autowired 
	SessionFactory sessionFac;
	@Transactional
	public List<Shopping> getData(String tabName) {
		System.out.println("in service");
		
		return ishopDao.getData(sessionFac,tabName);
	}
	@Transactional	
	public Item getItemDetails(Integer itemId) {
System.out.println("in service");
		
		return ishopDao.getItemDetails(sessionFac,itemId);
	}

}
