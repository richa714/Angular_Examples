package com.tcs.service;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.tcs.bean.Animal;
import com.tcs.dao.IAnimalDaoInterface;
import com.tcs.response.AnimalResponse;

@Service("service1")
public class AnimalServiceImpl implements IAnimalServiceInterface{
	
	@Autowired
	IAnimalDaoInterface adao;
	
	@Autowired 
	SessionFactory sessionFac;

	private static final Logger LOGGER=Logger.getLogger(AnimalServiceImpl.class.getName());
	@Transactional
	public List<Animal> getData() {
		
		LOGGER.log(Level.INFO,"inside service");
		return adao.getData(sessionFac);
	}
	
	

}
