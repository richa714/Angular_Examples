package com.tcs.service;

import java.util.List;

import com.tcs.bean.Item;
import com.tcs.bean.Shopping;

public interface IShoppingServiceInterface {
	public List<Shopping> getData(String tabName);
	public Item getItemDetails(Integer itemId);

}
