package com.tcs.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tcs.bean.Animal;

@Service("service2")
public class NewAnimalServiceImpl implements IAnimalServiceInterface{

	public List<Animal> getData() {
	System.out.println("in new interface");
		return null;
	}

}
