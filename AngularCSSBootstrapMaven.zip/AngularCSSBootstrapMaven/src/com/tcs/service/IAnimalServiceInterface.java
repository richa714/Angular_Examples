package com.tcs.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tcs.bean.Animal;
import com.tcs.response.AnimalResponse;


public interface IAnimalServiceInterface {
	public List<Animal> getData();

}
