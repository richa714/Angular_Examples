app.directive('slideConfig', function ($parse) {

		 return {    	

		        restrict: 'A',
		        scope:{
		        	slideConfig:'='

		        },
		        link: function (scope, element, attrs) {

		        	element.bind('click', function(event)
		             {


		        		if(scope.slideConfig)
		        			{
			        			$(element).next().slideUp(100, function() {

				 				  });
			        			scope.slideConfig=false;

		        			}
		        		else
		        			{
			        			$(element).next().slideDown( 100, function() {

				 				  });

			        			scope.slideConfig=true;
		        			}



		             });
		        }
		        };

	});

app.register.directive('tnc', function ($parse) {
	 return {    	
	        restrict: 'E',
	        scope:{
	        	requestType:'='
	        },
	        link: function (scope) {
	        	 scope.$watch('requestType', function () {

	                 if(scope.requestType=="self"){

			        		scope.path= 'Slm/Slm_Phase2/SlmViews/SlmInstallationTnCSelf'+'.html'
			        	}
			        	else if(scope.requestType=="project"){
			        		scope.path= 'Slm/Slm_Phase2/SlmViews/SlmInstallationTnCProject'+'.html'
			        	}
			        	else if(scope.requestType=="others"){
			        		scope.path= 'Slm/Slm_Phase2/SlmViews/SlmInstallationTnCOthers'+'.html'
			        	}
	             });





	        },
	        template: '<div ng-include="path"></div>',
	   //templateUrl:'Slm/Slm_Phase2/SlmViews/SlmInstallationTnC.html',////UtxFrmwk/WebContent/Slm/Slm_Phase2/SlmViews/AssetDetailsView.html
	    };	    
	    
	    
}); 


