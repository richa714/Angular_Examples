var app=angular.module('practiceApp',['ngRoute','ngResource','ngCookies']);

app.config(function($routeProvider)
		{
	
	$routeProvider
	.when("/trials",{
		templateUrl:"trials.html"
	})

	.when("/implementations",{

		templateUrl:"home.html",
		controller:"practiceCtrl"
		
	})
	.when("/shoppingCategories/:tabName",{

		templateUrl:"Shopping.html",
		controller:"shoppingCtrl",
		dependencies:['js/Services.js',
		              'js/ShoppingController.js']
		
	})
	.when("/itemDetails/:itemName/:itemId",{

		templateUrl:"ItemDetails.html",
		controller:"itemCtrl"
		
	})
	.when("/login",{
	templateUrl:"login.html",
	controller:"practiceCtrl"
	});
	
	/*.when("/customMenu/Supervisor",{

		templateUrl:"ParameterizedURL.html",
		controller:"practiceCtrl"
		
	})
	.when("/customMenu/Developer",{

		templateUrl:"ParameterizedURL.html",
		controller:"practiceCtrl"
		
	});*/
		}		


);